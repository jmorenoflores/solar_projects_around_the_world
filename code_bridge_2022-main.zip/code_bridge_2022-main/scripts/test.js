const jupyter = document.getElementsByClassName(".jp-Notebook");
console.log(jupyter);
// jupyter.classList.add("jp-Notebook-update");
